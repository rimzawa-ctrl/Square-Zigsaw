스퀘어 직소 / SQUARE JIGSAW  ·  Android APK 소스

게임 구성
- HTML/CSS/JS 전체와 샘플 이미지 25종, 스냅 효과음을 앱에 내장
- 메인 화면: 고르기 / 랜덤 / 내 이미지, ×1/×2/×3, 효과음 스위치
- 앱 이름: 스퀘어 직소
- 패키지 ID: com.rimzawa.squarejigsaw
- 최소 Android 7.0 (API 24), 대상 Android 15 (API 35)
- Galaxy 분할화면 대응: resizeableActivity, 자동 화면 재배치
- 외부 웹 연결 없이 로컬 에셋으로 실행; 이미지 파일 선택기 지원

스마트폰 GitHub 빌드 (폴더 업로드 불필요)
1) GitHub에서 새 저장소 Square-Jigsaw를 만듭니다. main 브랜치를 선택합니다.
2) 이 패키지와 함께 받은 square-jigsaw-android.zip을 저장소 최상위에 업로드/커밋합니다.
   (스마트폰 GitHub의 Add file > Upload files)
3) Add file > Create new file을 누르고 파일 이름에
     .github/workflows/build_square_jigsaw.yml
   을 적습니다. 별도로 제공한 build_square_jigsaw.yml의 내용을 모두 붙여넣고 커밋합니다.
4) Actions > Build Square Jigsaw APK > 최신 Run > Artifacts > Square-Jigsaw-APK를 받습니다.
   자동 실행이 되지 않았으면 Run workflow 버튼을 눌러 시작합니다.
5) ZIP 안의 app-debug.apk를 설치합니다.

Android Studio로 직접 빌드
- zip 내부를 추출한 디렉터리를 Android Studio로 열면 됩니다.
- Gradle 8.9 및 JDK 17, Android API 35가 필요합니다.
- android-source 폴더에서: gradle assembleDebug

설명
- GitHub ZIP은 안드로이드 소스와 빌드 설정을 담고 있으며 APK 자체가 아닙니다.
- 현재 ZIP은 업로드 후 GitHub Actions에서 컴파일되도록 준비한 것으로,
  이 작업 환경에는 Android SDK가 없어 실제 APK 컴파일은 수행하지 않았습니다.
- Debug APK는 Android의 테스트용 기본 서명 키로 서명됩니다.
- 기존 앱과 다른 패키지 ID로 설치됩니다.
- 기기에 따라 알 수 없는 앱 설치 허용이 필요할 수 있습니다.
- 추후 업데이트 APK는 동일한 서명 키로 서명해야 기존 앱을 덮어쓸 수 있습니다.
